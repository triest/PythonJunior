# Django settings for testing clients
CREDENTIALS_BY_PLATFORM = {
    "BINANCE": ("rlvKnLAocc9R4HLU8q51elHte7WCqRwXAHuQ6p1ltKmMkQc2QCah8aSo9p3SDoOG",
                "",  # "MvO6MAerLLi715qKGBRoKOSNAJXnAJpxfMHOU5uEAv6Yw5QyVJnFFQmjGTX7ZKNr"
                ),
    "BITFINEX": ("",
                 ""),
    "BITMEX": ("",
               ""),
    # ("zt2U_wjwvPPbPE3T6nRTzVKr",
    # "3p-tCyGeFJc6-_RL-Q_hnn9NPowI-zTkhOtcZZipHihzG1Qy"),
}
SECRET_KEY = "ddd"