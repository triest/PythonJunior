# hqlib
Common library for HyperQuant projects on Python

## Install

As separate project:

    pipenv install

Add as a library to your project:

    pipenv install -e git+https://github.com/hyperquant-platform/hqlib.git#egg=hqlib

Then, to update after hqlib changed:

    pipenv update
